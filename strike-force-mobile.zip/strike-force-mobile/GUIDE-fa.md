# راهنمای تست حداقلی (فقط با گوشی)

## ۱) مخزن GitHub
یک مخزن **Private** بسازید (مثلاً strike-force). رمز Unity شما به‌عنوان Secret در آن نگه‌داری می‌شود، پس عمومی نباشد.

## ۲) ساخت فایل‌ها
در مرورگر: Add file ← Create new file. مسیر را دقیقاً (با / ) در کادر نام بنویسید و محتوا را paste کنید.

| فایل این بسته | مسیر در مخزن |
|---|---|
| 1-activate-license.yml | .github/workflows/1-activate-license.yml |
| 2-build-android.yml | .github/workflows/2-build-android.yml |
| manifest.json | Packages/manifest.json |
| ProjectVersion.txt | ProjectSettings/ProjectVersion.txt |
| Bootstrap.cs | Assets/Scripts/Bootstrap.cs |
| BuildScript.cs | Assets/Editor/BuildScript.cs |

## ۳) حساب Unity و کلید Authenticator
1. در id.unity.com حساب بسازید.
2. در تنظیمات امنیتی، تأیید دومرحله‌ای با Authenticator را فعال کنید.
3. در صفحهٔ QR گزینهٔ «Can't scan the barcode?» را بزنید و کلید متنی را **بدون فاصله** ذخیره کنید.

## ۴) Secretها
Settings ← Secrets and variables ← Actions ← New repository secret:
- UNITY_EMAIL
- UNITY_PASSWORD
- UNITY_TOTP_KEY (کلید مرحلهٔ ۳)
- ACCESS_TOKEN: یک Personal Access Token در GitHub (Settings ← Developer settings) با دسترسی نوشتن به Secretsِ همین مخزن.

## ۵) اجرا
Actions ← «1 - Activate Unity license» ← Run workflow. اگر سبز شد، «2 - Build Android APK» را اجرا کنید و از Artifacts فایل APK را دانلود و نصب کنید.

## اگر خطا داد
لاگ یا تصویر error.png (Artifact) را برای من بفرستید.

## هشدار
نسخهٔ Unity (2022.3.20f1) و نسخهٔ ابزارها را من اینجا اجرا نکرده‌ام. ممکن است نسخه یا مرحله‌ای نیاز به اصلاح داشته باشد.
